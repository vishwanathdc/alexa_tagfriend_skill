const Constants = {
  FACTS: [
    'UTD was founded in 1969, and in only 34 years it has become one of the top universities in Texas, one with an emerging national reputation.',
    'UTD’s defined strategic intent is to be a nationally recognized, top-tier university sculpted with a model of focused excellence.',
    'UTD has developed a national -- and in some cases, international -- reputation in such areas as audiology, telecommunications, brain health, digital forensics and emergency preparedness, nanotechnology, sickle cell disease research and space sciences. ',
    'UTD was founded in 1969, and in only 34 years it has become one of the top universities in Texas, one with an emerging national reputation.',
    'UTD’s defined strategic intent is to be a nationally recognized, top-tier university sculpted with a model of focused excellence.',
    'UTD has developed a national -- and in some cases, international -- reputation in such areas as audiology, telecommunications, brain health, digital forensics and emergency preparedness, nanotechnology, sickle cell disease research and space sciences. '
  ]
};

module.exports = Constants;